VEDA KOUSHIK — SELF-CONTAINED PORTFOLIO

Open index.html in a modern web browser. The Resume page is embedded directly inside index.html and can be opened from the navigation or the View Full Resume button. No separate resume.html file is required.
